const UsersController = require('./controllers/users.controller');
const OrdersController = require('./controllers/orders.controller');
const ShippingsController = require('./controllers/shippings.controller');

exports.routesConfig = function (app) {
    app.post('/users', [
        UsersController.insert
    ]);
    app.get('/users', [
        UsersController.list
    ]);
    app.get('/users/:userId', [
        UsersController.getById
    ]);
    app.patch('/users/:userId', [
        UsersController.patchById
    ]);
    app.delete('/users/:userId', [
        UsersController.removeById
    ]);
    app.post('/orders', [
        OrdersController.insert
    ]);
    app.get('/orders', [
        OrdersController.list
    ]);
    app.get('/orders/:orderId', [
        OrdersController.getById
    ]);
    app.delete('/orders/:orderId', [
        OrdersController.removeById
    ]);
    app.post('/shippings', [
        ShippingsController.insert
    ]);
    app.get('/shippings', [
        ShippingsController.list
    ]);
    app.get('/shippings/:shippingId', [
        ShippingsController.getById
    ]);
    app.delete('/shippings/:shippingId', [
        ShippingsController.removeById
    ]);
    app.get('/shippings/city/:city', [
        ShippingsController.getByCity
    ]);
    app.get('/order/customers/listByCustomer', [
        OrdersController.listByCustomer
    ]);
    app.get('/shipmentDetail', [
        ShippingsController.listByShipment
    ]);
};