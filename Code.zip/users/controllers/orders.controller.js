const OrderModel = require('../models/orders.model');
const UserModel = require('../models/users.model');

exports.insert = (req, res) => {
    if (req.body.customerId.match(/^[0-9a-fA-F]{24}$/)) {
        if(req.body.pricing <= req.body.mrp){
        UserModel.findById(req.body.customerId).then((result) => {
            if(result!==null ||  result!==undefined){
                OrderModel.createOrder(req.body)
                .then((resultOrder) => {
                    res.status(201).send({id: resultOrder._id});
                });
            }
            else{
                res.status(201).send({Message: `User does not exist in the database`});
            }
        });
        }
        else{
            res.status(201).send({Message: `Pricing can't be greater than MRP`});
        }
    }
    else{
        res.status(201).send({Message: `User does not exist in the database`});
    }
};
exports.getById = (req, res) => {
    OrderModel.findById(req.params.orderId).then((result) => {
        console.log("ii", req.params.orderId, result)
        res.status(200).send(result);
    });
};
exports.list = (req, res) => {
    let limit = req.query.limit && req.query.limit <= 100 ? parseInt(req.query.limit) : 10;
    let page = 0;
    if (req.query) {
        if (req.query.page) {
            req.query.page = parseInt(req.query.page);
            page = Number.isInteger(req.query.page) ? req.query.page : 0;
        }
    }
    OrderModel.list(limit, page)
        .then((result) => {
            res.status(200).send(result);
        })
};

exports.removeById = (req, res) => {
    const deletedMsg = {Message : 'Customer deleted Successfully'}
    OrderModel.removeById(req.params.orderId)
        .then((result)=>{
            res.status(204).send(deletedMsg);
        });
};

exports.listByCustomer = (req, res) => {
    let limit = req.query.limit && req.query.limit <= 100 ? parseInt(req.query.limit) : 10;
    let page = 0;
    if (req.query) {
        if (req.query.page) {
            req.query.page = parseInt(req.query.page);
            page = Number.isInteger(req.query.page) ? req.query.page : 0;
        }
    }
    OrderModel.listByCustomer(limit, page)
        .then((result) => {
            res.status(200).send(result);
        })
};
