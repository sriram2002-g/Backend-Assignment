const OrderModel = require('../models/orders.model');
const ShippingModel = require('../models/shippings.model');

exports.insert = (req, res) => {
    if (req.body.customerId.match(/^[0-9a-fA-F]{24}$/) && req.body.orderId.match(/^[0-9a-fA-F]{24}$/)) {
                OrderModel.findById(req.body.orderId).then((resultOrder) => {
                    if(resultOrder!== null ||  resultOrder!== undefined){
                        console.log("hhhh", resultOrder)
                        if(resultOrder.customerId === req.body.customerId){
                            ShippingModel.createShipping(req.body)
                            .then((resultShipping) => {
                            res.status(201).send({id: resultShipping._id});
                            });
                        }
                        else{
                            res.status(201).send({Message: `Given CustomerID and orderId combination does not exist in the database`});
                        }
                    }
                    else{
                        res.status(201).send({Message: `OrderId does not exist in the database`});
                    }
                });
    }
    else{
        res.status(201).send({Message: `UserId or OrderId does not exist in the database`});
    }
};
exports.getById = (req, res) => {
    ShippingModel.findById(req.params.shippingId).then((result) => {
        console.log("ii", req.params.shippingId, result)
        res.status(200).send(result);
    });
};
exports.list = (req, res) => {
    let limit = req.query.limit && req.query.limit <= 100 ? parseInt(req.query.limit) : 10;
    let page = 0;
    if (req.query) {
        if (req.query.page) {
            req.query.page = parseInt(req.query.page);
            page = Number.isInteger(req.query.page) ? req.query.page : 0;
        }
    }
    ShippingModel.list(limit, page)
        .then((result) => {
            res.status(200).send(result);
        })
};

exports.removeById = (req, res) => {
    const deletedMsg = {Message : 'Shipping deleted Successfully'}
    ShippingModel.removeById(req.params.shippingId)
        .then((result)=>{
            res.status(204).send(deletedMsg);
        });
};

exports.getByCity = (req, res) => {
    ShippingModel.findByCity(req.params.city).then((result) => {
        console.log("ii", req.params.city, result)
        res.status(200).send(result);
    });
};

exports.listByShipment = (req, res) => {
    let limit = req.query.limit && req.query.limit <= 100 ? parseInt(req.query.limit) : 10;
    let page = 0;
    if (req.query) {
        if (req.query.page) {
            req.query.page = parseInt(req.query.page);
            page = Number.isInteger(req.query.page) ? req.query.page : 0;
        }
    }
    OrderModel.listByCustomer(limit, page)
        .then((result) => {
            ShippingModel.listByShipment(result)
            .then((resultShipping) => {
                res.status(200).send(resultShipping);
            })
        })
};