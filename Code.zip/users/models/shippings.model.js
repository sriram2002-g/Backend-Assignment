const mongoose = require('../../common/services/mongoose.service').mongoose;
const Schema = mongoose.Schema;

const shippingSchema = new Schema({
    addresss: String,
    city: String,
    pincode: Number,
    orderId: String,
    customerId: String
});

shippingSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

// Ensure virtual fields are serialised.
shippingSchema.set('toJSON', {
    virtuals: true
});

shippingSchema.findById = function (cb) {
    return this.model('Shippings').find({id: this.id}, cb);
};

const Shipping = mongoose.model('Shippings', shippingSchema);

exports.createShipping = (shippingData) => {
    const shipping = new Shipping(shippingData);
    return shipping.save();
};

exports.findById = (id) => {
    return Shipping.findById(id)
        .then((result) => {
            console.log("hh", typeof result)
            if(result!==null){
            result = result.toJSON();
            delete result._id;
            delete result.__v;
            return result;
            }
        });
};

exports.list = (perPage, page) => {
    return new Promise((resolve, reject) => {
        Shipping.find()
            .limit(perPage)
            .skip(perPage * page)
            .exec(function (err, shippings) {
                if (err) {
                    reject(err);
                } else {
                    resolve(shippings);
                }
            })
    });
};

exports.removeById = (shippingId) => {
    return new Promise((resolve, reject) => {
        Shipping.deleteMany({_id: shippingId}, (err) => {
            if (err) {
                reject(err);
            } else {
                resolve(err);
            }
        });
    });
};

exports.findByCity = (city) => {
    console.log("hhz", city)
    return Shipping.find({city: city})
};

exports.listByShipment = (resultArray) => {
    const resultArryModified =  resultArray.map(obj => { return obj[0].customerId})
    console.log("hw2",resultArryModified)
    const resultArrCust = resultArryModified.map(obj => { return Shipping.find({customerId: obj})})
    console.log("he", resultArrCust)
    //return Shipping.find({city: city})
};