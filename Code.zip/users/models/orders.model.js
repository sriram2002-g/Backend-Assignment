const mongoose = require('../../common/services/mongoose.service').mongoose;
const Schema = mongoose.Schema;

const orderSchema = new Schema({
    productName: String,
    quantity: Number,
    pricing: Number,
    mrp: Number,
    customerId: String
});

orderSchema.virtual('id').get(function () {
    return this._id.toHexString();
});

// Ensure virtual fields are serialised.
orderSchema.set('toJSON', {
    virtuals: true
});

orderSchema.findById = function (cb) {
    return this.model('Orders').find({id: this.id}, cb);
};

const Order = mongoose.model('Orders', orderSchema);

exports.createOrder = (orderData) => {
    const order = new Order(orderData);
    return order.save();
};

exports.findById = (id) => {
    return Order.findById(id)
        .then((result) => {
            console.log("hh", typeof result)
            console.log("adf2", result)
            if(result!==null){
            result = result.toJSON();
            delete result._id;
            delete result.__v;
            console.log("adf", result)
            return result;
            }
        });
};

exports.listByCustomer = (perPage, page) => {
    return new Promise((resolve, reject) => {
        Order.find()
            .limit(perPage)
            .skip(perPage * page)
            .exec(function (err, orders) {
                if (err) {
                    reject(err);
                } else {
                    //console.log("hh22", typeof orders, orders)
                    const uniqueCustId = [...new Set(orders.map(item => item.customerId))]
                    const uniqArray = uniqueCustId.map(obj => {
                        let filterArray = orders.filter(item => obj === item.customerId);
                        console.log("h12", filterArray)
                        return [{customerId: obj, purchaseOrder: filterArray}]
                    })
                    console.log("hh222", uniqArray)
                    resolve(uniqArray);
                }
            })
    });
};

exports.removeById = (orderId) => {
    return new Promise((resolve, reject) => {
        Order.deleteMany({_id: orderId}, (err) => {
            if (err) {
                reject(err);
            } else {
                resolve(err);
            }
        });
    });
};

exports.list = (perPage, page) => {
    return new Promise((resolve, reject) => {
        Order.find()
            .limit(perPage)
            .skip(perPage * page)
            .exec(function (err, orders) {
                if (err) {
                    reject(err);
                } else {
            resolve(orders);
                }
            })
    });
};